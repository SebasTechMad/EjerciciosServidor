<html>
<head>
    <meta charset="UTF-8">
        <link href="web/default.css" rel="stylesheet" type="text/css" />
        <title>NOTAS</title>
    </head>
    <body>
        <div id="container" style="width: 600px;">
            <div id="header">
                <h1>ACCESO DE NOTAS</h1>
            </div>
                <h1>Superado el número máximo de accesos erroneos</h1>
                <hr>
                <p>Reinicie el navegador para volver a intentarlo</p>
        </div>
    </body>
</html>