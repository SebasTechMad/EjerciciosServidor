<?php 
define('SERVER_DB','localhost');
define('DB_USER','root');
define('DB_PASSWD','');
define('DATABASE','ejercicio_php');

